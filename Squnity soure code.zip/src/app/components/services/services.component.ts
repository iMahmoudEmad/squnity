import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {
  services = [
    {
      id: '',
      image: '',
      name: 'Service Name',
      description: 'while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing.',
      link: ''
    },
    {
      id: '',
      image: '',
      name: 'Service Name',
      description: 'while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing.',
      link: ''
    },
    {
      id: '',
      image: '',
      name: 'Service Name',
      description: 'while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing.',
      link: ''
    },
    {
      id: '',
      image: '',
      name: 'Service Name',
      description: 'while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing.',
      link: ''
    },
    {
      id: '',
      image: '',
      name: 'Service Name',
      description: 'while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing.',
      link: ''
    },
    {
      id: '',
      image: '',
      name: 'Service Name',
      description: 'while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing while most people enjoy casino gambiling, sports betting lottery and bingo playing.',
      link: ''
    }
  ];

  constructor() {
  }

  ngOnInit() {
  }

}
