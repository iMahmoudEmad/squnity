import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-short-services',
  templateUrl: './short-services.component.html',
  styleUrls: ['./short-services.component.scss']
})
export class ShortServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
