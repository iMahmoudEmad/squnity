import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-why-choose-squnity',
  templateUrl: './why-choose-squnity.component.html',
  styleUrls: ['./why-choose-squnity.component.scss']
})
export class WhyChooseSqunityComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
