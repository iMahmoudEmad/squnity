import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-services',
  templateUrl: './check-services.component.html',
  styleUrls: ['./check-services.component.scss']
})
export class CheckServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
