import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-qoute',
  templateUrl: './company-qoute.component.html',
  styleUrls: ['./company-qoute.component.scss']
})
export class CompanyQouteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
